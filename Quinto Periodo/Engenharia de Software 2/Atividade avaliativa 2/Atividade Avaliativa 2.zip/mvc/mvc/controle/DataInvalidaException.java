package mvc.controle;

public class DataInvalidaException extends Exception {
    
}
