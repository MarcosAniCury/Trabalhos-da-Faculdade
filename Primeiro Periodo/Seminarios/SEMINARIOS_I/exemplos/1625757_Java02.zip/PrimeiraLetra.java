import java.util.Scanner;

public class PrimeiraLetra{

public static void main(String[] args){
	Scanner leitor = new Scanner(System.in);
	String frase = leitor.nextLine();
	char eliminar = 'a';
	String aux="";
	int pos=-1;
	do{
		pos++;
		System.out.println("Procurando "+eliminar+" na posição "+pos);
	}while(frase.charAt(i)!=eliminar);
	
	System.out.println("Achei "+eliminar+" na posição "+pos);
	
}

}
