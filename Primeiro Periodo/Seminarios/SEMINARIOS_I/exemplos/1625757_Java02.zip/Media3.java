import java.util.Scanner;

public class Media3{

public static void main(String[] args){
	Scanner leitor = new Scanner(System.in);
	final int QUANTPROVAS = 3;
	int quantAlunos=0;
	double notasAlunos[];
	int soma=0;
	double media;
	
	System.out.print("Quantos alunos existem? ");
	quantAlunos = leitor.nextInt();
	
	notasAlunos=new double[quantAlunos][QUANTPROVAS];
	System.out.println("Digite a nota para "+quantAlunos+" alunos");
	
	for(int i=0; i<quantAlunos; i++){
		for(int j=0; j<QUANTPROVAS; j++){
			System.out.printf("Nota %d do aluno %d: \n", (j+1), (i+1))
			notasAlunos[i][j] = leitor.nextDouble();
		}
	}
	for(int i=0; i<quantAlunos; i++){
		soma=0;
		for(int j=0; j<QUANTPROVAS; j++)
			soma+=notasAlunos[i][j];
	
		media = (double)soma/QUANTPROVAS;
	    System.out.printf("Média do aluno %d: %.2f\n:", (i+1), media);
	}
	

}

}
