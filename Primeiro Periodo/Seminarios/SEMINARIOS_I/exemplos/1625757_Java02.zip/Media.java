import java.util.Scanner;

public class Media{

public static void main(String[] args){
	Scanner leitor = new Scanner(System.in);
	int cont=0;
	int soma=0;
	double media;
	
	System.out.println("Digite uma sequência de números inteiros terminada com -1:");
	int numero = leitor.nextInt();
	while(numero != -1){
		soma+= numero;
		cont++;
		numero = leitor.nextInt();	
	}
	media = soma/cont;
	
	System.out.println("A média dos números é "+media);

}

}
