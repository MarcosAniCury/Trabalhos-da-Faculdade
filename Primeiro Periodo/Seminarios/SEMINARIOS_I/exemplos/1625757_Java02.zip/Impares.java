import java.util.Scanner;

public class Impares{

public static void main(String[] args){
	Scanner leitor = new Scanner(System.in);
	int cont=0;
	
	
	System.out.println("Digite uma sequência de números inteiros terminada com -1:");
	int numero = leitor.nextInt();
	while(numero != -1){
		if((numero%2)==1)
			cont++;
		numero = leitor.nextInt();	
	}
	System.out.println("Você digitou um total de "+cont+" números ímpares");

}

}
