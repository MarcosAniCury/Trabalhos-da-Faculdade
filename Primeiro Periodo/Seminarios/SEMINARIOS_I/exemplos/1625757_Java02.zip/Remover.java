import java.util.Scanner;

public class Remover{

public static void main(String[] args){
	Scanner leitor= new Scanner(System.in);
	String frase = leitor.nextLine();
	String eliminar = "a";
	String aux="";

	aux = frase.replace(eliminar, "");
	
	System.out.println(aux);
}

}
