import java.util.Scanner;

public class Menores{

public static void main(String[] args){
	Scanner leitor = new Scanner(System.in);
	int quant = leitor.nextInt();
	
	int numeros[]  = new int[quant];
			
	for(int i=0; i<quant; i++){
		numeros[i] = leitor.nextInt();
	}
	
	int minimo = leitor.nextInt();
	
	for(int valor : numeros){
		if(valor<minimo)
			System.out.println(valor+" abaixo de "+minimo);
	}
	
}

}
