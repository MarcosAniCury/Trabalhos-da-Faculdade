import java.util.Scanner;
import java.util.Arrays;

public class Arrays3{

public static void main(String[] args){
   Scanner leitor = new Scanner(System.in);
   
   int[] arr1 = {0,1,2,3,4};
   int[] arr2 = {4,3,2,1,0};

   boolean igual = Arrays.equals(arr1, arr2);
   
   if(igual)   
      System.out.println("Dois arrays iguais");
   else   
      System.out.println("Dois arrays diferentes");
   

}


}