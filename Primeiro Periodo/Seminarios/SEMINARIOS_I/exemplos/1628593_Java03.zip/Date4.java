import java.util.Scanner;
import java.util.Arrays;
import java.time.LocalDate;


public class Date4{

public static void main(String[] args){
   Scanner leitor = new Scanner(System.in);
   String dataStr1 = leitor.nextLine();
   int quantosDias = leitor.nextInt();
   int operacao = leitor.nextInt(); 
   
   LocalDate dataOriginal = LocalDate.parse(dataStr1);
   LocalDate novaData;
   if(operacao==0)
      novaData = dataOriginal.plusDays(quantosDias);
   else
      novaData = dataOriginal.minusDays(quantosDias);
   
   System.out.printf("\nData original: %02d/%02d/%d", dataOriginal.getDayOfMonth(),   
                                                 dataOriginal.getMonthValue(),
                                                 dataOriginal.getYear());
                                                 
   System.out.printf("\nData alterada: %02d/%02d/%d", novaData.getDayOfMonth(),   
                                                 novaData.getMonthValue(),
                                                 novaData.getYear());                                                 
}


}