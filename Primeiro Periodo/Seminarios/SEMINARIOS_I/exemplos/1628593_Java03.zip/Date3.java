import java.util.Scanner;
import java.util.Arrays;
import java.time.LocalDate;

public class Date3{

public static void main(String[] args){
   Scanner leitor = new Scanner(System.in);
   String dataStr1 = leitor.nextLine();
   String dataStr2 = leitor.nextLine();
   
   LocalDate data1 = LocalDate.parse(dataStr1);
   LocalDate data2 = LocalDate.parse(dataStr2);
      
   
   if(data1.equals(data2))
           System.out.println(data1+" é o mesmo dia de "+data2);
   else
           System.out.println(data1+" não é o mesmo dia de "+data2);
  
}


}