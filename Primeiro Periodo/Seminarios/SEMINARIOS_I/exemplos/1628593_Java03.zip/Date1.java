import java.util.Scanner;
import java.util.Arrays;
import java.time.LocalDate;

public class Date1{

public static void main(String[] args){
   Scanner leitor = new Scanner(System.in);
   int dia = leitor.nextInt();
   int mes = leitor.nextInt();
   int ano = leitor.nextInt();
   
   LocalDate data = LocalDate.of(ano, mes, dia);
   
   System.out.println(data);
   

   
  
}


}