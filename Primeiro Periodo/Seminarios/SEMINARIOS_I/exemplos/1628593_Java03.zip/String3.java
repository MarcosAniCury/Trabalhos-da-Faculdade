import java.util.Scanner;
import java.util.Arrays;

public class String3{

public static void main(String[] args){
   Scanner leitor = new Scanner(System.in);
   
   String frase = leitor.nextLine();
   String procura = leitor.nextLine();
   
   int pos = frase.indexOf(procura);
   
   if(pos>=0)
      System.out.println("Achei "+procura+" na posição "+pos);
   else
      System.out.println("Não existe "+procura);

}


}