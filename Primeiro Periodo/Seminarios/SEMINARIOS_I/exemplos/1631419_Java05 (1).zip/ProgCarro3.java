import java.util.Scanner;
import java.time.LocalDate;
import java.time.Period;
import java.util.Arrays;

class Carro implements Comparable {
	String placa;
	LocalDate dataModelo;
	double precoVenda;
	
	public Carro(String placa, int ano, double preco){
		this.placa = placa;
		this.precoVenda = preco;
		this.dataModelo = LocalDate.of(ano, 1, 1);
	
	}
	
	public double IPVA(){
		return this.precoVenda * 0.04;
	}
	
	public int idade(){
		Period intervalo = this.dataModelo.until(LocalDate.now());
		return intervalo.getYears();
	}
	
	@Override
	public String toString(){
		String aux = "Placa: " + this.placa; 
		aux += "\nAno: "+this.dataModelo.getYear() + " - "+this.idade()+" anos";
		aux += "\nPreço R$: "+String.format("%.2f", this.precoVenda);
		aux += "\nIPVA R$: "+String.format("%.2f", this.IPVA())+"\n";
		return aux;
	}
	
	@Override
	public boolean equals(Object object){
		Carro outro = (Carro)object;
		if(outro.placa.equals(this.placa))
			return true;
		else
			return false;
	}
	
	public int compareTo(Object obj){
		Carro outro = (Carro)obj;
		if(this.idade()<outro.idade())
			return -1;
		else if (this.idade()==outro.idade())
				return 0;
			 else
				return 1;
	}

	public double getPreco(){
		return this.precoVenda;
	}
}


class Frota{
	Carro[] carros;
	final int TAMFROTA;
	int qtdCarros;
	
	public Frota(int tamanho){
		this.TAMFROTA = tamanho;
		this.carros = new Carro[this.TAMFROTA];
		this.qtdCarros=0;
	
	} 
	
	public void lerCarros(){
		Scanner leitor = new Scanner(System.in);
		int quantCarros = leitor.nextInt();
		for(int i=0; i<quantCarros; i++){
			System.out.println(i);
			String placa = leitor.next();
			int ano = leitor.nextInt();
			double preco = leitor.nextDouble();
	
			Carro novoCarro = new Carro(placa, ano, preco);
			this.addCarro(novoCarro);
		}
	
	}
	
	public boolean addCarro(Carro novo){
		if(this.qtdCarros<this.TAMFROTA){
			this.carros[this.qtdCarros] = novo;
			this.qtdCarros++;
			return true;
		}
		else
			return false;
		
	}
	
	public double valorTotal(){
		double aux=0d;
		
		for(Carro c : carros){
			if(c!=null)
				aux += c.getPreco();
		}
	
		return aux;
	}
	
	public Carro carroMaisNovo(){
		Carro aux = this.carros[0];
		for(int i=1; i<this.qtdCarros; i++){
			if(carros[i].compareTo(aux)<0)
				aux = carros[i];
		}
	
		return aux;
	}
	
	@Override
	public String toString(){
		String aux="=== DETALHES DA FROTA ===\n";
		
		for(Carro c : carros){
			if (c!=null){
				aux += c.toString();
			}
		}
		
		aux+=("Valor total da frota: R$ "+this.valorTotal()+"\n");
		return aux;
	}
	
}

public class ProgCarro3{

public static void main(String[] args){
	
	
	Frota frota = new Frota(10);
	
	
	
	frota.lerCarros();
	
	System.out.println(frota.toString());
	
	Carro maisNovo = frota.carroMaisNovo();
	
	System.out.println("Carro mais novo da frota: "+maisNovo.toString());
	
	
}
}	
