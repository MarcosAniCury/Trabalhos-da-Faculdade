import java.util.Scanner;
import java.util.Arrays;

class Calculadora{
	double n1, n2, res;
	String operacao;
	
	public void calcular(){
		switch(this.operacao){
			case "+": this.res = this.n1+this.n2;
				break;
			case "-": this.res = this.n1-this.n2;
				break;
			case "*": this.res = this.n1*this.n2;
				break;
			case "/": this.res = this.n1/this.n2;
				break;
			default: this.res=0;
				break;
		}
	}
	
	@Override
	public String toString(){
		String aux = n1 + operacao + n2 + " = " + res;
		return aux;
	}
}

public class ProgCalculadora2{

public static void main(String[] args){
	Scanner leitor = new Scanner(System.in);
	
	int quantasOperacoes = leitor.nextInt();
	Calculadora calc1 = new Calculadora();
	
	for(int i=0; i<quantasOperacoes; i++){
		calc1.n1 = Double.parseDouble(leitor.next());
		calc1.operacao = leitor.next();
		calc1.n2 = Double.parseDouble(leitor.next());
	
		calc1.calcular();
		
		System.out.println(calc1.toString());
	}
}
}	
