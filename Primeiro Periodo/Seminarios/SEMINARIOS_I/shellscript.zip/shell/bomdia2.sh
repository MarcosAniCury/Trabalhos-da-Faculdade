#!/bin/bash
echo "Bom dia, $(whoami)"
echo "Agora são $(date)"
