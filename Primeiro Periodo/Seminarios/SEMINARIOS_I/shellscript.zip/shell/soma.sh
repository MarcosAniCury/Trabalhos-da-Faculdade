#!/bin/bash

echo -n "A soma é "
echo $(($1 + $2))
