#!/bin/bash

if ! [ -f ~/.bashrc ]
then
	echo "Não há arquivo persolanizado de inicialização"
else
	echo "Parabéns. Você tem um bashrc"
fi
