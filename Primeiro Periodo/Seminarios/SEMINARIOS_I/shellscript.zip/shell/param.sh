#!/bin/bash

echo "A linha de comando teve $# parâmetros"
echo "O programa chamado foi $0"
echo "O primeiro parâmetro foi $1"
