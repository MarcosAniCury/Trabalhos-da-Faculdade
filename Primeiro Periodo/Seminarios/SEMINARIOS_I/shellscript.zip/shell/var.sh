#!/bin/bash

dia='sexta'
echo -n "Qual é seu primeiro nome? "
read nome

echo "Bom dia, $nome. Tenha uma boa $dia"

