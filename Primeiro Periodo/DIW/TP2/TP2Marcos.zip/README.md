# Trabalho 2 DIW

- Caso tenha algum problema para acessar os items da página, favor chamar Miko#9331 no discord pois provavelmente o servidor aonde está hospedado a API caiu (feito em servidor separado com o aceite do Rommel)