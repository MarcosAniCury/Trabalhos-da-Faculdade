# Desafio CRUD

## Partes feitas:

* _"Log.java"_ --> pequeno arquivo que gera um logger para try catch (porque eu acho mais fácil debuggar assim do que vários sysout)
* _"CRUD.java"_ --> todas as funções solicitadas pelo professor
* _"livro.java"_ --> classe implementando a interface

## Partes dadas pelo professor
* _"Teste.java"_ --> script de teste
* _"Registro.java"_ --> interface 

## Partes a fazer
* ~~_"Registro.java"_ (concluído em 28/02)~~
* ~~_"livro.java"_ (concluído em 28/02)~~
* ~~_"log.java"_ (concluído em 28/02)~~
* ~~Crud --> Create (concluído em 28/02)~~
* ~~Crud --> Read (concluído em 01/03)~~
* ~~Crud --> Debug (concluído em 01/03)~~
* ~~Crud --> mais debugg (concluído em 02/03)~~
* ~~Crud --> update (concluído em 02/03)~~
* ~~Crud --> Delete (concluído em 02/03)~~
* ~~Crud --> debugg (concluído em 02/03)~~
* ~~_"CRUD.java"_ (concluído em 02/03)~~
* ~~Comentário e limpeza (concluído em 02/03)~~
