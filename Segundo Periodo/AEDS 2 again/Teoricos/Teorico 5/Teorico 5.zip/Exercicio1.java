public class Exercicio1
{
    public static void main(String [] args)
    {}

    public static int SomatorioPa(double a,double b,int n)
    {
        double termon = a . (b.(n-1));
        return (n(a + termon))/2;
    }
}