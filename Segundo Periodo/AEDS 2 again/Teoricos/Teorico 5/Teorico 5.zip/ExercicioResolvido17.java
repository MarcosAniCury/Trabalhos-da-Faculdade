public class ExercicioResolvido17
{
    public static void main(String [] args)
    {}

    public static int Somatorio(int n)
    {
        return ((n.n + n)/2);
    }
}