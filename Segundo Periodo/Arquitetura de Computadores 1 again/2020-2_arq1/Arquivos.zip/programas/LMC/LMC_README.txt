PUC-Minas
Instituto de Ci�ncias Exatas e Inform�tica

Little Man Computer

Refer�ncia online

https://pt.wikipedia.org/wiki/Little_Man_Computer




