//em java
void inserirheap(Int k)
{
    k++;
    heap[k] = array[k];
    while (k != 1)
    {
        if (heap[k] > heap[2/k])
        {
            troca(heap[k], heap[2/k]);
            k = 2/k;
        }
        else
            k = 1;
    }
}