//em java
void Mostrar2Pilhas(Pilha[] obj1,Pilha[] obj2)
{
    mostrar2pilha(obj1,obj2,0,0);
}

void mostrar2pilha(Pilha[] obj1, Pilha[] obj2,int nobj1,int nobj2)
{
    if (nobj1 < obj1.lenght - 1)
        MyIO.print(obj1[(obj1.lenght - 1) - nobj1]);
    if (nobj2 < obj2.lenght - 1)
        MyIO.print(obj2[(obj2.lenght - 1) - nobj2]);
    if (nobj1 < obj1.lenght - 1 || nobj2 < obj2.lenght - 1)
        mostrar2pilha(obj1,obj2,nobj1++,nobj2++);
}